package demmm;

public class factorial {
 
	public static void main(String[] args) {
		
		  int factorial=1;  
		  int n=7;   
		  for(int i=1;i<=n;i++){    
		      factorial=factorial*i;    
		  }    
		  System.out.println("Factorial of "+n+" is: "+factorial); 		
	}
}
